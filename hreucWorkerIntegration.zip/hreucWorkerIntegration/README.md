# hreucWorkerIntegration
Integration of Worker API/Topic with HREUC table HRDTBK.EMP
