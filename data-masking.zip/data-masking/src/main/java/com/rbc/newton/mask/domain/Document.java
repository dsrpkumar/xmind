package com.rbc.newton.mask.domain;

public class Document {
	private String entity;
	private Long id;
	
	
	public Document(String entity, Long id) {
		super();
		this.setEntity(entity);
		this.id = id;
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getEntity() {
		return entity;
	}

	public void setEntity(String entity) {
		this.entity = entity;
	}
}
