package com.rbc.newton.mask.domain;

public class DmRequestData {
	private Long revisionId;
	private int source;
	private Long requestDataId;
	private Long ruleExecutionId;
	private String elementPath;
	private String elementValue;
	private boolean processed;
	
	public Long getRequestDataId() {
		return requestDataId;
	}
	public void setRequestDataId(Long requestDataId) {
		this.requestDataId = requestDataId;
	}
	public Long getRuleExecutionId() {
		return ruleExecutionId;
	}
	public void setRuleExecutionId(Long ruleExecutionId) {
		this.ruleExecutionId = ruleExecutionId;
	}
	public String getElementValue() {
		return elementValue;
	}
	public void setElementValue(String elementValue) {
		this.elementValue = elementValue;
	}

	public int getSource() {
		return source;
	}

	public void setSource(int source) {
		this.source = source;
	}

	public String getElementPath() {
		return elementPath;
	}

	public void setElementPath(String elementPath) {
		this.elementPath = elementPath;
	}

	public Long getRevisionId() {
		return revisionId;
	}

	public void setRevisionId(Long revisionId) {
		this.revisionId = revisionId;
	}
	public boolean isProcessed() {
		return processed;
	}
	public void setProcessed(boolean processed) {
		this.processed = processed;
	}
}
