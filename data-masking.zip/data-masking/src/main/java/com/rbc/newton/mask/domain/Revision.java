package com.rbc.newton.mask.domain;

import java.util.HashMap;
import java.util.Map;

public class Revision {
	private Long id;
	private Map<String,DmRequestData> elements=new HashMap<String, DmRequestData>();
	
	public Revision(Long id){
		this.setId(id);
	}

	public Map<String,DmRequestData> getElements() {
		return elements;
	}

	public void addElement(DmRequestData element) {
		this.elements.put(element.getElementPath(),element);
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
}
