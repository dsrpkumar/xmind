package com.rbc.newton.mask.domain;

public class IdElemValue {
	private Long id;
	private String path;
	private String value;
	public IdElemValue(Long id, String path, String value) {
		super();
		this.setId(id);
		this.setPath(path);
		this.setValue(value);
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
}
