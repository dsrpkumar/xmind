package com.rbc.newton.mask.service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Semaphore;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rbc.newton.mask.dao.DmRequestDataDao;
import com.rbc.newton.mask.dao.MappingsDao;
import com.rbc.newton.mask.domain.Constants;
import com.rbc.newton.mask.domain.DmRequestData;
import com.rbc.newton.mask.domain.Document;
import com.rbc.newton.mask.domain.IdElemValue;
import com.rbc.newton.mask.domain.Mapping;
import com.rbc.newton.mask.domain.PathValue;
import com.rbc.newton.mask.domain.Revision;
import com.rbc.newton.util.SimpleGNUCommandLine;
import com.rbc.newton.util.Utils;

@Service
public class MaskingService {
	private Logger logger = Logger.getLogger(MaskingService.class);

	@Value("${core-pool-size}")
	private int core_pool_size;

	@Value("${maximum-pool-size}")
	private int maximum_pool_size;

	@Value("${keep-alive-time-milliseconds}")
	private int keep_alive_time_milliseconds;

	@Value("${queue-size}")
	private int queue_size;

	@Inject
	private JdbcTemplate jdbcTemplate;

	@Inject
	private DmRequestDataDao dmRequestDataDao;

	@Inject
	private MappingsDao mappingsDao;

	private static final String REINDEX_SQL_STMT = "insert into DM_INDEX_JOURNAL values ( -1,'MODIFIED',? )";
	private static final String AUDIT = "insert into AUDIT_MASKING values ( ?, ? ,?) ";
	private static final String UPDATE_DM_REQUEST_DATA="update DM_REQUEST_DATA set ELEMENT_VALUE=? where RULE_EXECUTION_ID=? and ELEMENT_PATH=?";
	private static final String UPDATE_DM_RD_DICT="update DM_RD_DICT set ELEMENT_VALUE=? where DM_RD_DICT_ID=? and ELEMENT_PATH=?";

	
	private int update(PathValue pv, List<Long> ids) {
		StringBuilder sb=new StringBuilder();
		for(Long id:ids){
			sb.append(sb.length()==0?" (":",").append(id);
		}
		sb.append(") ");
		String in_str=sb.toString();
		sb.setLength(0);
		sb.append("update ").append(pv.getSource()==1?"DM_REQUEST_DATA":"DM_RD_DICT");
		sb.append("\nset ELEMENT_VALUE=").append(pv.getValue()==null?"null":"'"+pv.getValue()+"'");
		sb.append("\nwhere ").append(pv.getSource()==1?"RULE_EXECUTION_ID in ":"DM_RD_DICT_ID in ").append(in_str);
		sb.append("\nand ELEMENT_PATH='").append(pv.getPath()).append("'");
		//System.out.println(sb.toString());
		return jdbcTemplate.update(sb.toString());
	}

//	private void addValue(DmRequestData rd, String value,Map<PathValue,List<Long>> map){
//		if ( StringUtils.equals(rd.getElementValue(), value)){
//			return;
//		}
//		PathValue pv=new PathValue(rd.getElementPath(),value,rd.getSource());
//		List<Long> list=map.get(pv);
//		if ( list==null ){
//			list=new ArrayList<Long>();
//			map.put(pv, list);
//		}
//		list.add(rd.getSource()==1?rd.getRuleExecutionId():rd.getRequestDataId());
//	}
//	private void processPath(Revision rev, List<Mapping> listMappings,Map<PathValue,List<Long>> map) {
//		boolean found=false;
//		for (Mapping mapping : listMappings) {
//			String prefix = mapping.getPrefix() + " ";
//			int ix = mapping.getPath().indexOf("[n]");
//			if (ix == -1) {
//				if ( ! found ){
//					DmRequestData rd = rev.getElements().get(mapping.getPath());
//					if (rd != null) {
//						if ("null".equals(mapping.getValue())) {
//							this.addValue(rd, null, map);
//							found=true;
//						} else {
//							DmRequestData rdval = rev.getElements().get(mapping.getValue());
//							if (rdval != null) {
//								this.addValue(rd, prefix + rdval.getElementValue(),  map);
//								found=true;
//							}
//						}
//					}
//				}
//			} else {
//				for (int i = 0; i < 10; i++) {
//					String path = mapping.getPath().replaceFirst("\\[n\\]", "[" + i + "]");
//					DmRequestData rd = rev.getElements().get(path);
//					if (rd == null) {
//						continue;
//					}
//					if ("null".equals(mapping.getValue())) {
//						this.addValue(rd, null, map);
//					} else {
//						DmRequestData rdval = rev.getElements()
//								.get(mapping.getValue().replaceFirst("\\[n\\]", "[" + i + "]"));
//						if (rdval != null) {
//							this.addValue(rd, prefix + rdval.getElementValue(), map);
//						}
//					}
//				}
//			}
//		}
//	}
//
//	private int processElements(Document doc, Map<Long, Revision> revisions, Map<String, List<Mapping>> mappings) {
//		int rows_updated = 0;
//		Map<PathValue,List<Long>> map=new HashMap<PathValue,List<Long>>();
//		for (Revision rev : revisions.values()) {
//			for (String path : mappings.keySet()) {
//				this.processPath(rev, mappings.get(path), map);
//			}
//		}
//		for(PathValue pv:map.keySet()){
//			List<Long> list=map.get(pv);
//			if ( list==null || list.size() < 1 ){
//				continue;
//			}
//			rows_updated+=update(pv,list);
//		}
//		return rows_updated;
//	}

	private void addValue(DmRequestData rd, String value, List<IdElemValue> dm_list, List<IdElemValue> dict_list) {
		if ( StringUtils.equals(rd.getElementValue(), value)){
			return;
		}
		if ( rd.getSource()==1 ){
			dm_list.add(new IdElemValue(rd.getRuleExecutionId(),rd.getElementPath(),value));
		} else {
			dict_list.add(new IdElemValue(rd.getRequestDataId(),rd.getElementPath(),value));
		}
	}

	private void processPath(Revision rev, List<Mapping> listMappings,List<IdElemValue> dm_list, List<IdElemValue> dict_list) {
		boolean found=false;
		for (Mapping mapping : listMappings) {
			String prefix = mapping.getPrefix() + " ";
			int ix = mapping.getPath().indexOf("[n]");
			if (ix == -1) {
				if ( ! found ){
					DmRequestData rd = rev.getElements().get(mapping.getPath());
					if (rd != null) {
						if ("null".equals(mapping.getValue())) {
							this.addValue(rd, null, dm_list, dict_list);
							found=true;
						} else {
							DmRequestData rdval = rev.getElements().get(mapping.getValue());
							if (rdval != null) {
								this.addValue(rd, prefix + rdval.getElementValue(),  dm_list, dict_list);
								found=true;
							}
						}
					}
				}
			} else {
				for (int i = 0; i < 10; i++) {
					String path = mapping.getPath().replaceFirst("\\[n\\]", "[" + i + "]");
					DmRequestData rd = rev.getElements().get(path);
					if (rd == null) {
						continue;
					}
					if ("null".equals(mapping.getValue())) {
						this.addValue(rd, null, dm_list, dict_list);
					} else {
						DmRequestData rdval = rev.getElements()
								.get(mapping.getValue().replaceFirst("\\[n\\]", "[" + i + "]"));
						if (rdval != null) {
							this.addValue(rd, prefix + rdval.getElementValue(), dm_list, dict_list);
						}
					}
				}
			}
		}
	}

	private int batchUpdate(int source, final List<IdElemValue> list) throws Exception {
		int[] rows=jdbcTemplate.batchUpdate(source==1?UPDATE_DM_REQUEST_DATA:UPDATE_DM_RD_DICT, new BatchPreparedStatementSetter(){

			@Override
			public int getBatchSize() {
				return list.size();
			}

			@Override
			public void setValues(PreparedStatement pstmt, int i) throws SQLException {
				IdElemValue iev=list.get(i);
				if ( iev.getValue()==null ){
					pstmt.setNull(1, Types.VARCHAR);
				} else {
					pstmt.setString(1, iev.getValue());
				}
				pstmt.setLong(2, iev.getId());
				pstmt.setString(3, iev.getPath());
			}});
		int nbr=0;
		for(int i:rows){
			if ( i == -2 ) {
				nbr ++;
			}
		}
		return nbr;
	}
	private synchronized int processDictBatch(List<IdElemValue> dict_list) throws Exception {
		return this.batchUpdate(2, dict_list);
	}
	private int processElements(Document doc, Map<Long, Revision> revisions, Map<String, List<Mapping>> mappings) throws Exception {
		int rows_updated = 0;
		List<IdElemValue> dm_list=new ArrayList<IdElemValue>();
		List<IdElemValue> dict_list=new ArrayList<IdElemValue>();
		for (Revision rev : revisions.values()) {
			for (String path : mappings.keySet()) {
				this.processPath(rev, mappings.get(path), dm_list, dict_list);
			}
		}
		if( dm_list.size() > 0 ){
			rows_updated += this.batchUpdate(1, dm_list);
		}
		if( dict_list.size() > 0 ){
			rows_updated += this.processDictBatch(dict_list);
		}
		return rows_updated;
	}

	//@Transactional
	private int processDocument(Document doc, Map<Long, Revision> revisions, boolean onlyCurrentRevision) throws Exception {
		logger.info("Processing " + doc.getEntity() + " " + doc.getId());
		int rows_updated = 0;
		if (Constants.CLIENT.equals(doc.getEntity())) {
			rows_updated += jdbcTemplate.update("update RBC_P_CLIENT set CLIENT_NM=?, LEGAL_NAME=? where ID=?",
					Constants.NAME_PREFIX + doc.getId(), Constants.LEGAL_PREFIX + doc.getId(), doc.getId());
		} else if (Constants.STMT.equals(doc.getEntity())) {
			rows_updated += jdbcTemplate.update("update FS_STATEMENT set BUSINESS_PARTNER_NAME=? where STATEMENT_ID=?",
					Constants.NAME_PREFIX + doc.getId(), doc.getId());
		}
		if (revisions.size() == 0) {
			logger.info("No revisions for the document " + doc.getId());
		} else {
			switch (doc.getEntity()) {
			case Constants.CLIENT:
				rows_updated += this.processElements(doc, revisions, mappingsDao.getClientMappings());
				break;
			case Constants.RATING:
				rows_updated += this.processElements(doc, revisions, mappingsDao.getAssessmentMappings());
				break;
			case Constants.STMT:
				rows_updated += this.processElements(doc, revisions, mappingsDao.getFinancialMappings());
				break;
			}
			if ( onlyCurrentRevision ){
				jdbcTemplate.update(REINDEX_SQL_STMT, doc.getId());
			}
		}
		jdbcTemplate.update(AUDIT, doc.getId(), new Date(), rows_updated);
		logger.info("Updated " + rows_updated + " row(s) in " + doc.getEntity() + " " + doc.getId());
		return rows_updated;
	}

	private String getSql(String entity, boolean onlyCurrentRevision) {
		String whereClause = null;
		switch (entity) {
		case Constants.CLIENT:
			whereClause = mappingsDao.getClientWhereClause();
			break;
		case Constants.STMT:
			whereClause = mappingsDao.getStmtWhereClause();
			break;
		case Constants.RATING:
			whereClause = mappingsDao.getRatingWhereClause();
			break;
		}
		StringBuilder sb = new StringBuilder();
		sb.append(
				"select rev.REVISION_ID, 1 as SRC,rd.REQUEST_DATA_ID as ID, rd.RULE_EXECUTION_ID, rd.ELEMENT_NAME, rd.ELEMENT_PATH, rd.ELEMENT_VALUE");
		sb.append("\nfrom DM_REQUEST_DATA rd");
		sb.append("\ninner join DM_RULE_EXECUTION re on re.RULE_EXECUTION_ID=rd.RULE_EXECUTION_ID");
		sb.append("\ninner join DM_REVISION_REQUEST rr on rr.REQUEST_ID=re.REQUEST_ID");
		sb.append("\ninner join DM_REVISION rev on rev.REVISION_ID=rr.REVISION_ID");
		if ( onlyCurrentRevision ){
			sb.append("\ninner join DM_HEADER h ON h.LATEST_REVISION_ID=rev.REVISION_ID and h.HEADER_ID=?");
		} else {
			sb.append("\ninner join DM_HEADER h ON h.HEADER_ID=rev.HEADER_ID and h.LATEST_REVISION_ID != rev.REVISION_ID and h.HEADER_ID=?");
		}
		sb.append(whereClause);
		sb.append("\nUNION ALL");
		sb.append(
				"\nselect rev.REVISION_ID, 2 as SRC, rd.DM_RD_DICT_ID as ID, rel.DM_RD_RULE_EXECUTION_ID, rd.ELEMENT_NAME, rd.ELEMENT_PATH, rd.ELEMENT_VALUE");
		sb.append("\nfrom DM_RD_DICT rd");
		sb.append("\ninner join DM_RD_DICT_REL rel on rel.DM_RD_DICT_ID=rd.DM_RD_DICT_ID");
		sb.append("\ninner join DM_RULE_EXECUTION re on re.RULE_EXECUTION_ID=rel.DM_RD_RULE_EXECUTION_ID");
		sb.append("\ninner join DM_REVISION_REQUEST rr on rr.REQUEST_ID=re.REQUEST_ID");
		sb.append("\ninner join DM_REVISION rev on rev.REVISION_ID=rr.REVISION_ID");
		if ( onlyCurrentRevision ){
			sb.append("\ninner join DM_HEADER h ON h.LATEST_REVISION_ID=rev.REVISION_ID and h.HEADER_ID=?");
		} else {
			sb.append("\ninner join DM_HEADER h ON h.HEADER_ID=rev.HEADER_ID and h.LATEST_REVISION_ID != rev.REVISION_ID and h.HEADER_ID=?");
		}
		sb.append(whereClause);
		return sb.toString();
	}

	private void process(final String entity, String idstr, Integer limit, final boolean onlyCurrentRevision) throws Exception {
		mappingsDao.load();
		String clientSql = this.getSql(Constants.CLIENT, onlyCurrentRevision);
		String stmtSql = this.getSql(Constants.STMT, onlyCurrentRevision);
		String ratingSql = this.getSql(Constants.RATING, onlyCurrentRevision);

		List<Document> docs = new ArrayList<Document>();

		if ("all".equals(idstr)) {
			if (Constants.CLIENT.equals(entity) || "all".equals(entity)) {
				logger.info("Identify client ids");
				List<Long> ids = jdbcTemplate
						.query("select distinct c.ID from RBC_P_CLIENT c join DM_HEADER h on h.HEADER_ID=c.ID left join AUDIT_MASKING m on c.ID=m.DOC_ID where m.DOC_ID is null"
								+ (limit != null && limit > 0 ? " and rownum <= " + limit : ""), new RowMapper<Long>() {

									public Long mapRow(ResultSet rs, int arg1) throws SQLException {
										return rs.getLong(1);
									}
								});
				logger.info("Number of entries: " + ids.size());
				for (Long id : ids) {
					docs.add(new Document(Constants.CLIENT, id));
				}
			}
			if (Constants.STMT.equals(entity) || "all".equals(entity)) {
				logger.info("Identify statement ids");
				List<Long> ids = jdbcTemplate
						.query("select distinct s.DOCUMENT_ID from FS_STATEMENT s join DM_HEADER h on h.HEADER_ID=s.STATEMENT_ID left join AUDIT_MASKING m on s.DOCUMENT_ID=m.DOC_ID where m.DOC_ID is null"
								+ (limit != null && limit > 0 ? " and rownum <= " + limit : ""), new RowMapper<Long>() {

									public Long mapRow(ResultSet rs, int arg1) throws SQLException {
										return rs.getLong(1);
									}
								});
				logger.info("Number of entries: " + ids.size());
				for (Long id : ids) {
					docs.add(new Document(Constants.STMT, id));
				}
			}
			if (Constants.RATING.equals(entity) || "all".equals(entity)) {
				logger.info("Identify risk assessment ids");
				List<Long> ids = jdbcTemplate
						.query("select distinct r.ID from RBC_P_RATING r join DM_HEADER h on h.HEADER_ID=r.ID left join AUDIT_MASKING m on r.ID=m.DOC_ID where m.DOC_ID is null"
								+ (limit != null && limit > 0 ? " and rownum <= " + limit : ""), new RowMapper<Long>() {

									public Long mapRow(ResultSet rs, int arg1) throws SQLException {
										return rs.getLong(1);
									}
								});
				logger.info("Number of entries: " + ids.size());
				for (Long id : ids) {
					docs.add(new Document(Constants.RATING, id));
				}
			}
		} else {
			String[] ss = idstr.split(",");
			switch (entity) {
			case Constants.CLIENT:
				for (String s : ss) {
					docs.add(new Document(Constants.CLIENT, Long.valueOf(s.trim())));
				}
				break;
			case Constants.RATING:
				for (String s : ss) {
					docs.add(new Document(Constants.RATING, Long.valueOf(s.trim())));
				}
				break;
			case Constants.STMT:
				for (String s : ss) {
					docs.add(new Document(Constants.STMT, Long.valueOf(s.trim())));
				}
				break;
			}
		}

		final AtomicInteger rows_updated = new AtomicInteger(0);
		final AtomicInteger docs_updated = new AtomicInteger(0);
		BlockingQueue<Runnable> queue = new ArrayBlockingQueue<Runnable>(queue_size);
		ThreadPoolExecutor exec = new ThreadPoolExecutor(core_pool_size, maximum_pool_size,
				keep_alive_time_milliseconds, TimeUnit.MILLISECONDS, queue, new ThreadPoolExecutor.CallerRunsPolicy());
		final Semaphore semaphore = new Semaphore(maximum_pool_size);
		for (final Document doc : docs) {
			final String sql = Constants.CLIENT.equals(doc.getEntity()) ? clientSql
					: (Constants.STMT.equals(doc.getEntity()) ? stmtSql : ratingSql);
			exec.execute(new Runnable() {

				@Override
				public void run() {
					try {
						semaphore.acquire();
						Map<Long, Revision> revisions = dmRequestDataDao.getRevisions(doc.getId(), sql);
						int nbr_rows = processDocument(doc, revisions,onlyCurrentRevision);
						rows_updated.addAndGet(nbr_rows);
						revisions.clear();
						revisions = null;
						int nbr = docs_updated.incrementAndGet();
						if (nbr % 100 == 0) {
							logger.info("Processed " + nbr + " documents and " + rows_updated.get() + " rows");
						}
					} catch (Exception ex) {
						logger.error("Error processing document "+doc.getId(),ex);
					} finally {
						semaphore.release();
					}
				}
			});
		}
		exec.shutdown();
		exec.awaitTermination(4, TimeUnit.HOURS);
		logger.info("Processing completed. Total Documents: " + docs_updated + ", Rows: " + rows_updated);
	}

	public static void main(String[] args) throws Exception {
		System.setProperty("app.name", "masking-service");
		Utils.setEnvironment();
		Logger logger = Logger.getLogger(MaskingService.class);
		SimpleGNUCommandLine cmd = new SimpleGNUCommandLine(args);
		cmd.addOption("type", "client, rating, stmt or all", true, true);
		cmd.addOption("id", "all or comma separated list of doc ids", true, true);
		cmd.addOption("limit", "Limit", true, false);
		ClassPathXmlApplicationContext appln_context = null;
		try {
			appln_context = new ClassPathXmlApplicationContext("spring/Context.xml");
			MaskingService processor = appln_context.getBean(MaskingService.class);
			//logger.info("Process current revisions");
			//processor.process(cmd.getString("type"), cmd.getString("id"), cmd.getInteger("limit"),true);
			logger.info("Process other revisions");
			processor.process(cmd.getString("type"), cmd.getString("id"), cmd.getInteger("limit"),false);
			System.exit(1);
		} catch (Exception ex) {
			logger.error("Data masking failed ", ex);
			System.exit(0);
		} finally {
			if (appln_context != null) {
				appln_context.close();
			}
		}
	}
}
