package com.rbc.newton.util;

import java.io.InputStream;
import java.util.Properties;

public class Utils {
	public static void setEnvironment() throws Exception {
		Properties props=new Properties();
		InputStream stream =Utils.class.getClass().getResourceAsStream("/environment.properties");
		props.load(stream);
		String env=props.getProperty("ENV");
		if ( env==null ){
			throw new Exception("ENV property is missing in environment.properties");
		}
		System.setProperty("env", env);
		
		String logdir=props.getProperty("LOG_DIR");
		if ( logdir==null ){
			throw new Exception("LOG_DIR property is missing in environment.properties");
		}
		System.setProperty("log.dir", logdir);
		System.out.println("env is "+env+" & log.dir is "+logdir);
	}
}
