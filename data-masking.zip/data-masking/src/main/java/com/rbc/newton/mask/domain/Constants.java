package com.rbc.newton.mask.domain;

public class Constants {
	public static final String CLIENT="client";
	public static final String RATING="rating";
	public static final String STMT="stmt";
	
	public static final String NAME_PREFIX="Name_";
	public static final String LEGAL_PREFIX="Legal_Name_";
	
	public static final String UNDEFINED="n/a";
}
