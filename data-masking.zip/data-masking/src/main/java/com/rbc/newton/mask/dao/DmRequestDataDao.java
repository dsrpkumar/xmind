package com.rbc.newton.mask.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.stereotype.Service;

import com.rbc.newton.mask.domain.DmRequestData;
import com.rbc.newton.mask.domain.Revision;

@Service
public class DmRequestDataDao {
	private Logger logger=Logger.getLogger(DmRequestDataDao.class);
	
	@Inject
	private JdbcTemplate jdbcTemplate;
	
	public Map<Long,Revision> getRevisions(Long docId, String sql){
		logger.info("Get details of document "+docId);
		final Map<Long,Revision> revisions=new HashMap<Long,Revision>();
		jdbcTemplate.query(sql, new Object[]{docId,docId}, new RowCallbackHandler(){
			@Override
			public void processRow(ResultSet rs) throws SQLException {
				DmRequestData rd=new DmRequestData();
				rd.setElementPath(rs.getString("ELEMENT_PATH"));
				rd.setElementValue(rs.getString("ELEMENT_VALUE"));
				rd.setRequestDataId(rs.getLong("ID"));
				rd.setRevisionId(rs.getLong("REVISION_ID"));
				rd.setRuleExecutionId(rs.getLong("RULE_EXECUTION_ID"));
				rd.setSource(rs.getInt("SRC"));
				Revision rev=revisions.get(rd.getRevisionId());
				if ( rev==null ){
					rev=new Revision(rd.getRevisionId());
					revisions.put(rd.getRevisionId(), rev);
				}
				rev.addElement(rd);
			}});
		return revisions;
	}
}
