package com.rbc.newton.mask.dao;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.rbc.newton.mask.domain.Constants;
import com.rbc.newton.mask.domain.Mapping;

@Service
public class MappingsDao {
	private Logger logger=Logger.getLogger(MappingsDao.class);
	
	private Map<String,List<Mapping>> clientMappings=new HashMap<String,List<Mapping>>();
	private Map<String,List<Mapping>> assessmentMappings=new HashMap<String,List<Mapping>>();
	private Map<String,List<Mapping>> financialMappings=new HashMap<String,List<Mapping>>();
	
	private String clientWhereClause=null;
	private String stmtWhereClause=null;
	private String ratingWhereClause=null;
	
	private String getWhereClause(Map<String,List<Mapping>> mappings){
		StringBuilder sb=new StringBuilder();
		Set<String> eqpaths=new HashSet<String>();
		Set<String> likepaths=new HashSet<String>();
		for(List<Mapping> list:mappings.values()){
			for(Mapping mapping:list){
				String path=mapping.getPath();
				if ( StringUtils.isBlank(path) || "null".equals(path)){
					continue;
				}
				int ix=path.indexOf("[");
				if ( ix == -1 ){
					eqpaths.add(path);
				} else {
					likepaths.add(path.replaceFirst("\\[n\\]", "[%]"));
				}
			}
			for(Mapping mapping:list){
				String path=mapping.getValue();
				if ( StringUtils.isBlank(path) || "null".equals(path)){
					continue;
				}
				int ix=path.indexOf("[");
				if ( ix == -1 ){
					eqpaths.add(path);
				} else {
					likepaths.add(path.replaceFirst("\\[n\\]", "[%]"));
				}
			}
		}
		for(String path:eqpaths){
			sb.append(sb.length()==0?"\nwhere ":"\nor ").append("ELEMENT_PATH='").append(path).append("'");
		}
		for(String path:likepaths){
			sb.append(sb.length()==0?"\nwhere ":"\nor ").append("ELEMENT_PATH like '").append(path).append("'");
		}
		return sb.toString();
	}
	public void load() throws Exception {
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("mappings.csv").getFile());
		logger.info("Load mappings from "+file.getAbsoluteFile());
		int nbr = 0;
		try (Scanner scanner = new Scanner(file)) {
			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				nbr++;
				if ( nbr ==1 ){
					continue;
				}
				String[] ss=line.split(",");
				Mapping mapping=new Mapping();
				mapping.setEntity(ss[0]);
				mapping.setPath(ss[1]);
				mapping.setValue(ss[2]);
				mapping.setPrefix(ss.length < 4 || StringUtils.isBlank(ss[3])?Constants.NAME_PREFIX:ss[3]);
				switch( mapping.getEntity()){
				case Constants.CLIENT:
					List<Mapping> listc=clientMappings.get(mapping.getPath());
					if ( listc==null ){
						listc=new ArrayList<Mapping>();
						clientMappings.put(mapping.getPath(),listc);
					}
					listc.add(mapping);
					break;
				case Constants.RATING:
					List<Mapping> listr=assessmentMappings.get(mapping.getPath());
					if ( listr==null ){
						listr=new ArrayList<Mapping>();
						assessmentMappings.put(mapping.getPath(),listr);
					}
					listr.add(mapping);
					break;
				case Constants.STMT:
					List<Mapping> listf=financialMappings.get(mapping.getPath());
					if ( listf==null ){
						listf=new ArrayList<Mapping>();
						financialMappings.put(mapping.getPath(),listf);
					}
					listf.add(mapping);
					break;
				}
			}
			scanner.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		setClientWhereClause(this.getWhereClause(clientMappings));
		setStmtWhereClause(this.getWhereClause(financialMappings));
		setRatingWhereClause(this.getWhereClause(assessmentMappings));
	}

	public Map<String,List<Mapping>> getClientMappings() {
		return clientMappings;
	}

	public Map<String,List<Mapping>> getAssessmentMappings() {
		return assessmentMappings;
	}

	public Map<String,List<Mapping>> getFinancialMappings() {
		return financialMappings;
	}
	public String getClientWhereClause() {
		return clientWhereClause;
	}
	public void setClientWhereClause(String clientWhereClause) {
		this.clientWhereClause = clientWhereClause;
	}
	public String getStmtWhereClause() {
		return stmtWhereClause;
	}
	public void setStmtWhereClause(String stmtWhereClause) {
		this.stmtWhereClause = stmtWhereClause;
	}
	public String getRatingWhereClause() {
		return ratingWhereClause;
	}
	public void setRatingWhereClause(String ratingWhereClause) {
		this.ratingWhereClause = ratingWhereClause;
	}
	
}
