#! /bin/sh

CP=.
CP=$CP:../lib/*
CP=$CP:../config

JAVA_OPTS="-Xmx1024m -Dapp.name=export-document"

${JAVA_HOME}/bin/java ${JAVA_OPTS} -classpath $CP com.rbc.newton.mask.service.MaskingService $*
